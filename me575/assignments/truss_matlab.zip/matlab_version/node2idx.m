function idx = node2idx(node, DOF)
%{
You do not need to change this function
It computes the appropriate indices in the global matrix for
the corresponding node numbers.  You pass in the number of the node
(either as a scalar or an array of locations), and the degrees of
freedom per node and it returns the corresponding indices in
the global matrices
%}

idx = [];

for i = 1:length(node)

    start = DOF*(node(i)-1) + 1;
    finish = DOF*node(i);

    idx = [idx start:finish];


end