function [K, S, dKdA] = bar(E, A, L, phi)
%{
Compute the stiffness and stress matrix for one element

Parameters
----------
E : float
    modulus of elasticity
A : float
    cross-sectional area
L : float
    length of element
phi : float
    orientation of element

Outputs
-------
K : 4 x 4 ndarray
    stiffness matrix
S : 1 x 4 ndarray
    stress matrix
dKdA : 4 x 4 ndarray
    derivative of stiffness matrix w.r.t. A

%}


% Your code goes here
